package main.java.com.zhengjun.cn.app;

import sun.tools.jar.CommandLine;

import java.io.IOException;

public class ToDoApp {
    public static void main(String[] args) throws IOException {
        String[] strings = CommandLine.parse(args);
    }
}
